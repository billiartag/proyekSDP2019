<?php
$config['firebase_app_key'] = __DIR__ . '/../config/proyeksdp2019-897a2-firebase-adminsdk-wivx1-375c7e6809.json';
