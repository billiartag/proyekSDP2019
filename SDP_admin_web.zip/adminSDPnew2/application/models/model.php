<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    class model extends CI_Model{
        public function __construct()
        {
            parent::__construct();
            $this->load->library('firebase');
        }
        public function get_ref($ref){
            $firebase = $this->firebase->init();
		    $db = $firebase->getDatabase();
            
            return $db->getReference($ref)->getValue();
        }
        public function get_data($ref,$id){
            $firebase = $this->firebase->init();
		    $db = $firebase->getDatabase();
            
            return $db->getReference($ref.'/'.$id)->getValue();
        }
        public function update_data($ref,$id,$data){
            $firebase = $this->firebase->init();
		    $db = $firebase->getDatabase();
            
		    $db->getReference($ref.'/'.$id)->update($data);
        }
        public function get_url($jenis,$directory,$id){
            $firebase = $this->firebase->init();
            $db = $firebase->getDatabase();
            
            $storage = $firebase->getStorage();
            $datetime = new DateTime('tomorrow');
            $url = "";
            if($jenis=="barang"){
                $url = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ8NDQ4NFREWFhURExcYHSggGBolHRMTITEhJSkrLi4uFx8zODMsNygtLisBCgoKBQUFDgUFDisZExkrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIALEBHAMBIgACEQEDEQH/xAAbAAEBAQEBAQEBAAAAAAAAAAAAAgEEAwUHBv/EADQQAQEAAgACBQoGAwADAAAAAAABAhEDBBIhMUFRExQyYXFygZGhsQUzUmKS4SJCwSPR8P/EABQBAQAAAAAAAAAAAAAAAAAAAAD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwD9EAAAAAAaxoA0AGgA1ugYN00EitGgSK0aBJpWmAzTFMBIpgJGgMY2sAAAAAAAAAAAAgNjWRoDRoEaRoGjTZGyAzTdN03QJ03StGgTpml6NAjRpWjQI0zS9MsBDF2JBLFMBNZVJoAAAAAAAAAABAgNimNBsbobAJFQkbAJFaJFSAzTdK03QJ0aXo0CNGnthwssvRlv2dOHIX/a69U6wfP0zT1yx1dd86qmwHnpli9MsB52MsXYmwEaZV1IIqauooAAAAAAAAAABAgKiomLBsbGRUBsVIyLgEipCPbhcvnl2Y9XjeqA85FTF3cLkZ/td+qdUe+sOHO7H70HFw+Tzvb/AIz19rq4fKYTt/yvr7PknPnJ/rN+u9Uc/E4uWXberwnVAdmfHww6t/DFnL8x07ZrWuuexwaXwcujlL8L7Abz3D1nvuy6/j3uax9TnMOlh68ev/2+bYDzsTY9LE2A86mrsTQRU1dTQedRV1NBgAAAAAAAAABAgKi4mKgKiomLgKwxtsk67eyO7g/h+V9KzH1dtcWFsss7Zdz2vuYZ9LDpY983PVQRw+V4eHXrfry63rhnjlvo2XXVdPkZ8TLK/wCVt9XdPg7vw70cvb/wHRnjb/tZ7NPG8pj33L5x5cxxs5nlJlZOrw8EeXz/AFX6A6PNMfHL6N80x8cvo55xs/1X6N8tn+q/QHv5pj45fRnmmPjl9Hj5bP8AVfoeXz/VfoDtmOprt6tdbn8yx8cvo8Lx8/1X6MvHz/VfoDo8xx8cvo4ONh0cssZ2S6fS5PO5Y227vSv/AB8/mvTz96g56mrqaCKirqaDzyRV5IoMAAAAAAAAAAIEBcXERUBUXERcBUfU/DOJvG4eHXPZXy46OT4nQzxvd2X2UHtzvD6Odvdl1/HvdH4d6OXt/wCK57h7w3349fw70/h3o5e3/gPHmfzMvh9nvyvBlnSs3vs32PDmvzMvh9ovl+Y6M1ez1dwPbmODNbkks8HI9+PzHSmpOrv28Aa3oXo9Lu3pvCw6V18/Y7uhNdHu1oHzamurLldS3e7JdTTloO3kfQvvX7Rw816eftru5D0L71+0cPNenn7aDxqKqpoIqaqpoPPJFXkigwAAAAAAAAAAgQFRcRFgqKiIqAuLjzlVKD7XK59PhzfX1dHJPJYdHp4+GWvo5vwzi6yuP6pue2f/AH0fRmM3b462D53NfmZfD7R5yq5u/wDky+H2hy/Cud8JO2gvhcK5b13d/r8E3Gy6s6/B9HDGSanZG2Tw7OwEcDh9Geu9r0AB8ri49HKzwv0fVfP/ABDHWUy8Zr4wHvyHoX3r9o4Oa9PP3q7vw/0L71+0cHN/mZ+9QeNTW1NBlRVVNBGSKuooMAAAAAAAAAAIEBUVEqBUbEtgLlVKhsoPbhZ9GzKdsu33ccpZLOyzcfz0r6PJ87jjhMcrdzetTfUCeb4eV4mVmOVnV1yWzsjMLxsZqTOT3f6dXn/C8b/Gnn3D8b8qDn8pxv3/AMf6b5Tjfv8A4/06PPuH435U8+4fjflQc/lON+/+P9HlON+/+P8ATo8+4fjflTz7h+N+VBzeU4/7/wCP9I4nlcurKZ3v9Guzz7h+N+VZ5/w/G/xoN/D8bMLuWf5Xtmu6Pnc3+Zn71fQ8/wCF43+NfL5jOZZ5Wdlu4CLU2lqQLU1tTQTUVdRQAAAAAAAAAACADYpMaCo1LQVFSobKC5WyolbsHpK3bz23YPTZtGzYL2bRs2Cts2nbLQVam1m2bBu2WsrAGDAZUqTQAAAAAAAAAAAAbGpaDWpaCm7SArbUgL23aG7BWzaTYK2bTs2Cts2zbAbs2xgNYwAGAMrK2sAAAAAAAAAAAAAABoxoNGAKGAKNpaDdm2AKZtgDdm2MBow2ADAAYAAAAAAAAAAAAAAAAAAA2AAADYAAAAAAUAYAAMAAAAAAAAAAAf/Z";
			}
            else if($jenis == "profile"){
                $url = "https://upload.wikimedia.org/wikipedia/commons/8/89/Portrait_Placeholder.png";
            }
            else if($jenis == "ktp"){
                $url = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ8NDQ4NFREWFhURExcYHSggGBolHRMTITEhJSkrLi4uFx8zODMsNygtLisBCgoKBQUFDgUFDisZExkrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrKysrK//AABEIALEBHAMBIgACEQEDEQH/xAAbAAEBAQEBAQEBAAAAAAAAAAAAAgEEAwUHBv/EADQQAQEAAgACBQoGAwADAAAAAAABAhEDBBIhMUFRExQyYXFygZGhsQUzUmKS4SJCwSPR8P/EABQBAQAAAAAAAAAAAAAAAAAAAAD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwD9EAAAAAAaxoA0AGgA1ugYN00EitGgSK0aBJpWmAzTFMBIpgJGgMY2sAAAAAAAAAAAAgNjWRoDRoEaRoGjTZGyAzTdN03QJ03StGgTpml6NAjRpWjQI0zS9MsBDF2JBLFMBNZVJoAAAAAAAAAABAgNimNBsbobAJFQkbAJFaJFSAzTdK03QJ0aXo0CNGnthwssvRlv2dOHIX/a69U6wfP0zT1yx1dd86qmwHnpli9MsB52MsXYmwEaZV1IIqauooAAAAAAAAAABAgKiomLBsbGRUBsVIyLgEipCPbhcvnl2Y9XjeqA85FTF3cLkZ/td+qdUe+sOHO7H70HFw+Tzvb/AIz19rq4fKYTt/yvr7PknPnJ/rN+u9Uc/E4uWXberwnVAdmfHww6t/DFnL8x07ZrWuuexwaXwcujlL8L7Abz3D1nvuy6/j3uax9TnMOlh68ev/2+bYDzsTY9LE2A86mrsTQRU1dTQedRV1NBgAAAAAAAAABAgKi4mKgKiomLgKwxtsk67eyO7g/h+V9KzH1dtcWFsss7Zdz2vuYZ9LDpY983PVQRw+V4eHXrfry63rhnjlvo2XXVdPkZ8TLK/wCVt9XdPg7vw70cvb/wHRnjb/tZ7NPG8pj33L5x5cxxs5nlJlZOrw8EeXz/AFX6A6PNMfHL6N80x8cvo55xs/1X6N8tn+q/QHv5pj45fRnmmPjl9Hj5bP8AVfoeXz/VfoDtmOprt6tdbn8yx8cvo8Lx8/1X6MvHz/VfoDo8xx8cvo4ONh0cssZ2S6fS5PO5Y227vSv/AB8/mvTz96g56mrqaCKirqaDzyRV5IoMAAAAAAAAAAIEBcXERUBUXERcBUfU/DOJvG4eHXPZXy46OT4nQzxvd2X2UHtzvD6Odvdl1/HvdH4d6OXt/wCK57h7w3349fw70/h3o5e3/gPHmfzMvh9nvyvBlnSs3vs32PDmvzMvh9ovl+Y6M1ez1dwPbmODNbkks8HI9+PzHSmpOrv28Aa3oXo9Lu3pvCw6V18/Y7uhNdHu1oHzamurLldS3e7JdTTloO3kfQvvX7Rw816eftru5D0L71+0cPNenn7aDxqKqpoIqaqpoPPJFXkigwAAAAAAAAAAgQFRcRFgqKiIqAuLjzlVKD7XK59PhzfX1dHJPJYdHp4+GWvo5vwzi6yuP6pue2f/AH0fRmM3b462D53NfmZfD7R5yq5u/wDky+H2hy/Cud8JO2gvhcK5b13d/r8E3Gy6s6/B9HDGSanZG2Tw7OwEcDh9Geu9r0AB8ri49HKzwv0fVfP/ABDHWUy8Zr4wHvyHoX3r9o4Oa9PP3q7vw/0L71+0cHN/mZ+9QeNTW1NBlRVVNBGSKuooMAAAAAAAAAAIEBUVEqBUbEtgLlVKhsoPbhZ9GzKdsu33ccpZLOyzcfz0r6PJ87jjhMcrdzetTfUCeb4eV4mVmOVnV1yWzsjMLxsZqTOT3f6dXn/C8b/Gnn3D8b8qDn8pxv3/AMf6b5Tjfv8A4/06PPuH435U8+4fjflQc/lON+/+P9HlON+/+P8ATo8+4fjflTz7h+N+VBzeU4/7/wCP9I4nlcurKZ3v9Guzz7h+N+VZ5/w/G/xoN/D8bMLuWf5Xtmu6Pnc3+Zn71fQ8/wCF43+NfL5jOZZ5Wdlu4CLU2lqQLU1tTQTUVdRQAAAAAAAAAACADYpMaCo1LQVFSobKC5WyolbsHpK3bz23YPTZtGzYL2bRs2Cts2nbLQVam1m2bBu2WsrAGDAZUqTQAAAAAAAAAAAAbGpaDWpaCm7SArbUgL23aG7BWzaTYK2bTs2Cts2zbAbs2xgNYwAGAMrK2sAAAAAAAAAAAAAABoxoNGAKGAKNpaDdm2AKZtgDdm2MBow2ADAAYAAAAAAAAAAAAAAAAAAA2AAADYAAAAAAUAYAAMAAAAAAAAAAAf/Z";
		    }

            if($storage->getBucket()->object($directory.'/'.$id)->exists()){
				$url = $storage->getBucket()->object($directory.'/'.$id)->signedUrl($datetime);
            }
            return $url;
        }
        public function insert_data($ref,$data){
            $firebase = $this->firebase->init();
            $db = $firebase->getDatabase();

            $db->getReference($ref)->push($data);    

        }
    }


?>