<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('model');
	}
	public function index()
	{
		$this->load->view('login');
	}
	public function login(){
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		if($username=="admin"&&$password=="admin"){
			redirect('Welcome/home');
		}
		else{
			$this->index();
		}
	}
	public function home(){
		$this->load->view('home');
	}
	public function master_user(){
		$data['data_user'] = $this->model->get_ref('UserDatabase');
		$this->load->view('master_user',$data);	
	}
	public function master_voucher(){
		$data['data_voucher'] = $this->model->get_ref('Voucher');
		$this->load->view('master_voucher',$data);	
	}
	public function master_barang(){
		$data['data_barang'] = $this->model->get_ref('BarangDatabase');
		$data['url'] = array();
		foreach($data['data_barang'] as $row){
			$url = $this->model->get_url('barang','img_barang',$row['id']);
			$data['url'][$row['id']] = $url;
		}
		$this->load->view('master_barang',$data);	
	}
	public function keluhan(){
		$data['data_keluhan'] = $this->model->get_ref('ReportDatabase');
		$this->load->view('keluhan',$data);	
	}
	public function update_user(){
		$id = $this->input->post('id');
		$value = $this->input->post('value');
		
		//update
		$data = [
			'status' => $value,
		];
		
		$this->model->update_data('UserDatabase',$id,$data);
		$this->master_user();
	}
	public function update_promo(){
		$id = $this->input->post('id');
		$value = $this->input->post('value');

		//update
		$data = [
			'status_promo' => $value,
		];
		
		$this->model->update_data('Voucher',$id,$data);
		$this->master_voucher();
	}
	public function detail_user(){
		$id = $this->input->post('id');
		$data['detail_user'] = $this->model->get_data('UserDatabase',$id);
		$email = "";
		$row = $data['detail_user'];
		$email = $row['email'];
		
		
		$url = $this->model->get_url('profile','profil_picture',$email);
		$data['url_user'] = $url;

		$url = $this->model->get_url('ktp','foto_ktp',$email);
		$data['url_ktp'] = $url;
		$this->load->view('detail_user',$data);
	}
	public function edit_user(){
		$id = $this->input->post('id');

		$email = $this->input->post('email');
		$password = $this->input->post('password');
		$nama = $this->input->post('nama');
		$phone = $this->input->post('phone');

		$data = [
			"email" => $email,
			"password" => $password,
			"nama" => $nama,
			"phone" => $phone
		];
		$this->model->update_data('UserDatabase',$id,$data);
		$this->master_user();
	}
	public function insert_promo(){
		$this->form_validation->set_rules('deskripsi_promo', 'deskripsi Promo', 'required');
		$this->form_validation->set_rules('nama_promo', 'nama promo', 'required');
		$this->form_validation->set_rules('mulai_promo', 'tanggal mulai promo', 'required');
		$this->form_validation->set_rules('selesai_promo', 'tanggal selesai promo', 'required');
		$this->form_validation->set_rules('diskon_promo', 'diskon promo', 'required');
		if ($this->form_validation->run() ==FALSE) {
			$this->session->set_flashdata('error',validation_errors());
		}
		else{
			$data = [
				"deskripsi_promo" => $this->input->post('deskripsi_promo'),
				"nama_promo" => $this->input->post('nama_promo'),
				"mulai_promo" => $this->input->post('mulai_promo'),
				"selesai_promo" => $this->input->post('selesai_promo'),
				"diskon_promo" => $this->input->post('diskon_promo'),
				"status_promo" => 1,
	
			];
			$this->model->insert_data('Voucher',$data);
		}
		return $this->master_voucher();
	}
	public function edit_verifikasi_ktp(){
		$id = $this->input->post('id');
		$value = $this->input->post('value');
		$data = [
			"verifikasi_ktp" => $value,
		];
		
		$this->model->update_data('UserDatabase',$id,$data);
		$this->master_user();

	}
	public function laporan(){
		$data['data_barang'] = $this->model->get_ref('BarangDatabase');
		$data['data_laporan'] = $this->model->get_ref('TransaksiDatabase');

		$this->load->view('laporan',$data);
	}
	public function update_status_barang(){
		$id = $this->input->post('id');
		$value = $this->input->post('value');
		
		$data = [
			"status" => $value,
		];
		
		$this->model->update_data('BarangDatabase',$id,$data);
		$this->master_barang();
	}
	public function get_data_barang(){
		$id = $this->input->post('id');
		$data['data_barang'] = $this->model->get_data('BarangDatabase',$id);
		$this->output->set_content_type('application/json')->set_output(json_encode($data));
	}
	public function get_data_keluhan(){
		$id = $this->input->post('id');
		$data['data_keluhan'] = $this->model->get_data('ReportDatabase',$id);
		$this->output->set_content_type('application/json')->set_output(json_encode($data));
	}
}
