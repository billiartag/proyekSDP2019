
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> -->





<div class="container">
        <hr><h1>List User</h1><hr>
        <table id="datatablediv">
            <thead>
                <tr>
                    <th>ID Report</th>
                    <th>Waktu Report</th>
                    <th>pelapor</th>
                    <th>Subject Report</th>
                    <th></th>
                </tr>
            </thead>
        </table>
    </div>

    <!-- The Modal -->
    <div class="modal" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Detail Report</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                ID : <p id='modal_id'></p><br>
                Pelapor : <p id="modal_pelapor"></p><br>
                Terlapor : <p id="modal_terlapor"></p><br>
                Waktu : <p id="modal_waktu"></p><br>
                <hr>
                Masalah : <p id="modal_masalah"></p><br>
                Keterangan : <br><p id="modal_keterangan"></p>
                <hr>


            </div>

            <!-- Modal footer -->
            <div class="modal-footer">
                <!-- <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button> -->
            </div>

            </div>
        </div>
    </div>


<?php
    $data_array = array();
    foreach($data_keluhan as $row){
        // echo $row['email'];
        array_push($data_array,$row);
    }
    // echo "<hr>";
    $encode_array = json_encode($data_array);
    // var_dump($encode_array)."<br>";
    
?>

<script type='text/javascript'>
    
    function lihat_detail(key){
        $.ajax({
                "url" : "<?=site_url('Welcome/get_data_keluhan')?>",
                "method" : "post",
                "data" : {
                    "id" : key
                },
                success : function(ret){
                    document.getElementById("modal_waktu").innerHTML = ret.data_keluhan.waktu_pelaporan;
                    document.getElementById("modal_id").innerHTML = ret.data_keluhan.id_report;
                    document.getElementById("modal_pelapor").innerHTML = ret.data_keluhan.user_pelapor;
                    document.getElementById("modal_terlapor").innerHTML = ret.data_keluhan.user_dilapor;
                    document.getElementById("modal_masalah").innerHTML = ret.data_keluhan.masalah_report;
                    document.getElementById("modal_keterangan").innerHTML = ret.data_keluhan.keterangan_report;
                    alert("Data Loaded!");
                }
            });
    }
    


    tableData = $("#datatablediv").dataTable({
        data : <?=$encode_array?>,
        aoColumns : [
            {mData : "id_report"},
            {mData : "waktu_pelaporan"},
            {mData : "user_pelapor"},
            {mData : "masalah_report"},
            {
                mData : function(data,type,full){
                    var waktu_pelaporan = data.waktu_pelaporan;
                    var user_pelapor = data.user_pelapor;
                    var user_dilapor = data.user_dilapor;
                    var masalah_report = data.masalah_report;
                    var keterangan_report = data.keterangan_report;
                    document.getElementById("modal_waktu").innerHTML = waktu_pelaporan;
                    document.getElementById("modal_id").innerHTML = data.id_report;
                    document.getElementById("modal_pelapor").innerHTML = user_pelapor;
                    document.getElementById("modal_terlapor").innerHTML = user_dilapor;
                    document.getElementById("modal_masalah").innerHTML = masalah_report;
                    document.getElementById("modal_keterangan").innerHTML = keterangan_report;
                    


                    var hasil = "<button class='btn btn-info' onclick=lihat_detail('"+data.id_report+"') data-toggle='modal' data-target='#myModal'>"+"Lihat Detail"+"</button>";
                    return hasil;
                }
            }
        ]
    });


    

</script>
