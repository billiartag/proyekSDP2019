<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Admin Page</title>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->

    <!-- Bootstrap CSS CDN -->
    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous"> -->
    <!-- Our Custom CSS -->
    <!-- <link rel="stylesheet" href="style.css"> -->

    <!-- datatable -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.css">
    
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.js"></script>

    <!-- Canvas JS -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/canvasjs/1.7.0/canvasjs.js"></script>


    <style type='text/css'>
    @import "https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700";


        body {
            font-family: 'Poppins', sans-serif;
            background: #fafafa;
        }

        p {
            font-family: 'Poppins', sans-serif;
            font-size: 1.1em;
            font-weight: 300;
            line-height: 1.7em;
            color: #999;
        }

        a, a:hover, a:focus {
            color: inherit;
            text-decoration: none;
            transition: all 0.3s;
        }

        #sidebar {
            /* don't forget to add all the previously mentioned styles here too */
            background: #7386D5;
            color: #fff;
            transition: all 0.3s;
        }

        #sidebar .sidebar-header {
            padding: 20px;
            background: #6d7fcc;
        }

        #sidebar ul.components {
            padding: 20px 0;
            border-bottom: 1px solid #47748b;
        }

        #sidebar ul p {
            color: #fff;
            padding: 10px;
        }

        #sidebar ul li a {
            padding: 10px;
            font-size: 1.1em;
            display: block;
        }
        #sidebar ul li a:hover {
            color: #7386D5;
            background: #fff;
        }

        #sidebar ul li.active > a, a[aria-expanded="true"] {
            color: #fff;
            background: #6d7fcc;
        }
        ul ul a {
            font-size: 0.9em !important;
            padding-left: 30px !important;
            background: #6d7fcc;
        }
        .wrapper {
            display: flex;
            width: 100%;
            align-items: stretch;
        }
        #sidebar {
            width: 250px;
            position: relative;
            top: 0;
            left: 0;
            height: 180vh;
            z-index: 999;
            background: #7386D5;
            color: #fff;
            transition: all 0.3s;
        }
    </style>

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
</head>

<body>


    <!-- Popper.JS -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script> -->
    <!-- Bootstrap JS -->
    <!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script> -->

        <!-- A grey horizontal navbar that becomes vertical on small screens -->
        <nav class="navbar navbar-expand-sm bg-primary">

            <!-- Links -->
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="#" style='color:white;'>Welcome, Admin!</a>
                </li>
                <!-- <li class="nav-item pull-right">
                    <button class="nav-link btn" href="<?=site_url('Welcome/')?>">Logout</button>
                </li> -->
            </ul>
            <div class="float-right">
                <a class="btn btn-dark" href="<?=site_url('Welcome/')?>">Logout</a>
            </div>
        </nav>
            

    <!-- sidebar -->
    <div class="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar">
            <!-- <div class="sidebar-header">
                <h3>Bootstrap Sidebar</h3>
            </div> -->

            <ul class="list-unstyled components">
                <!-- <p>Dummy Heading</p> -->
                <!-- <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Home</a>
                    <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="#">Home 1</a>
                        </li>
                        <li>
                            <a href="#">Home 2</a>
                        </li>
                        <li>
                            <a href="#">Home 3</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">About</a>
                </li> -->
                <li>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Master Pages</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <button class='btn btn-outline-warning' style='width:100%;' onclick='call_master_user()'>
                                <span id='spinner_user' class='spinner-grow spinner-grow-sm'></span>
                                Master User
                            </button>
                        </li>
                        <li>
                            <button class='btn btn-outline-warning' style='width:100%;' onclick='call_master_voucher()'>
                                <span id='spinner_voucher' class='spinner-grow spinner-grow-sm'></span>
                                Master Voucher
                            </button>
                        </li>
                        <li>
                            <button class='btn btn-outline-warning' style='width:100%;' onclick='call_master_keluhan()'>
                                <span id='spinner_keluhan' class='spinner-grow spinner-grow-sm'></span>
                                Keluhan
                            </button>
                        </li>
                        <li>
                            <button class='btn btn-outline-warning' style='width:100%;' onclick='call_master_barang()'>
                                <span id='spinner_barang' class='spinner-grow spinner-grow-sm'></span>
                                Master Barang
                            </button>
                        </li>
                    </ul>
                </li>
                <li>
                    <a onclick='call_master_laporan()'>Laporan</a>
                </li>
                <!-- <li>
                    <a href="#">Contact</a>
                </li> -->
            </ul>

        </nav>
        <!-- Page Content -->
        <div id="content" class='container'>

            
        </div>
    </div>



</body>
<script type='text/javascript'>
    function call_master_user(){
        $("#spinner_user").show();
        $.ajax({
            "url" : "<?=site_url('Welcome/master_user')?>",
            "method" : "post",
            "data" : {},
            success : function(data){
                $("#content").html(data);
            },
            complete : function(){
                $("#spinner_user").hide();
            }

        });
    }
    function call_master_voucher(){
        $("#spinner_voucher").show();
        $.ajax({
            "url" : "<?=site_url('Welcome/master_voucher')?>",
            "method" : "post",
            "data" : {},
            success : function(data){
                $("#content").html(data);
            },
            complete : function(){
                $("#spinner_voucher").hide();

            }

        });
    }
    function call_master_barang(){
        $("#spinner_barang").show();
        $.ajax({
            "url" : "<?=site_url('Welcome/master_barang')?>",
            "method" : "post",
            "data" : {},
            success : function(data){
                $("#content").html(data);
            },
            complete : function(){
                $("#spinner_barang").hide();

            }

        });
    }
    function call_master_laporan(){
        //alert('laporan!');
        $.ajax({
            "url" : "<?=site_url('Welcome/laporan')?>",
            "method" : "post",
            "data" : {},
            success : function(data){
                $("#content").html(data);
            },
            complete : function(){}
        });
    }
    function call_master_keluhan(){
        $("#spinner_keluhan").show();
        $.ajax({
            "url" : "<?=site_url('Welcome/keluhan')?>",
            "method" : "post",
            "data" : {},
            success : function(data){
                $("#content").html(data);
            },
            complete : function(){
                $("#spinner_keluhan").hide();

            }

        });
    }
    
    $(document).ready(function(){
        
        $("#spinner_keluhan").hide();
        $("#spinner_voucher").hide();
        $("#spinner_user").hide();
        $("#spinner_barang").hide();
        call_master_user();
    });
</script>
</html>