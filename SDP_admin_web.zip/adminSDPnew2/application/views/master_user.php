<div class="container">
        <hr><h1>List User</h1><hr>
        <table id="datatablediv">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Saldo</th>
                    <th>Nomor Telepon</th>
                    <th>Rating</th>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
        </table>
    </div>



<?php
    $data_array = array();
    foreach($data_user as $row){
        // echo $row['email'];
        array_push($data_array,$row);
    }
    // echo "<hr>";
    $encode_array = json_encode($data_array);
    // var_dump($encode_array)."<br>";
    
?>

<script type='text/javascript'>
    function toggle_activate(key,value){

        $.ajax({
            "url" : "<?=site_url('Welcome/update_user')?>",
            "method" : "post",
            "data" : {
                "id" : key,
                "value" : value
            },
            success : function(callback){
                $("#content").html(callback);
            }
        });

    }
    function lihat_detail(key){
        // alert("key : "+key);
        $.ajax({
            "url" : "<?=site_url('Welcome/detail_user')?>",
            "method" : "post",
            "data" : {
                "id" : key
            },
            success : function(callback){
                $("#content").html(callback);
            }
        });
    }



    tableData = $("#datatablediv").dataTable({
        data : <?=$encode_array?>,
        aoColumns : [
            {mData : "nama"},
            {mData : "email"},
            {
                mData : function(data,type,full){
                    return "Rp. "+data.saldo;
                }
            },
            {mData : "phone"},
            {mData : "rating"},
            {
                mData : function(data,type,full){
                    var hasil = "";
                    if(data.status == 0){
                        hasil = "<button class='btn btn-primary' style='width:100%;'onclick="+''+"toggle_activate('"+data.id+"',1)"+''+'>'+"Aktifkan"+"</button>";
                    }
                    else{
                        hasil = "<button class='btn btn-danger' style='width:100%;'onclick="+''+"toggle_activate('"+data.id+"',0)"+''+'>'+"Non Aktifkan"+"</button>";
                    }
                    return hasil;
                }
            },
            {
                mData : function(data,type,full){
                    var hasil = "<button class='btn btn-info' onclick=lihat_detail('"+data.id+"')>"+"Lihat Detail"+"</button>";
                    return hasil;
                }
            }
        ]
    });


    

</script>
