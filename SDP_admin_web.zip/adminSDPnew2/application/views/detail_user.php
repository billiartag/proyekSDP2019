<?php
        $id = "";
        $nama = "";
        $email = "";
        $password = "";
        $phone = "";
        $rating = 0;
        $saldo = 0;
        $profile_picture = "";
        $status_user = 0;
        $status_ktp = 0;
        
        //$data_array = array();
        // echo $row['email'];
        //array_push($data_array,$row);
        $id = $detail_user['id'];
        $nama = $detail_user['nama'];
        $email = $detail_user['email'];
        $password = $detail_user['password'];
        $phone = $detail_user['phone'];
        $profile_picture = $detail_user['profil_picture'];
        $rating = $detail_user['rating'];
        $saldo = $detail_user['saldo'];
        $status_ktp = $detail_user['verifikasi_ktp'];
        $status_user = $detail_user['status'];
            
        
    ?>
<style type='text/css'>
    #profile_pic{
        width : 200px;
        height : 200px; 
    }
    #ktp_picture{
        width : 350px;
        height : 200px;
    }
    </style>
<hr>
<div class="row">
    <div class="col-md-1"></div>
    <div class="col-md-5">
        <hr>
        <img src="<?=$url_user?>" alt="profile picture" id='profile_pic' name='profile_pic'/>
        <hr>
        ID : <br>
        <input type="text" name='id' id='id' value='<?=$id?>' disabled><br>
    </div>
    <div class="col-md-5">
        <h3>Data User</h3>
        Email : <br>
        <input type="text" name='email' id='email' value='<?=$email?>'><br>
        Password : <br>
        <input type="password" name='password' id='password' value="<?=$password?>"><br>
        name : <br>
        <input type="text" name='nama' id='nama' value="<?=$nama?>"><br>
        Phone : <br>
        <input type="number" name='phone' id='phone' value='<?=$phone?>'><br><br>
        <button type="submit" class='btn btn-primary' value="edit" name='edit' id='edit' onclick='edit_user()'>Edit</button>
    </div>
    <div class="col-md-1"></div>
</div>
<hr>
<div class="row">
    <div class="col-md-1"></div>
    <div class="col-md-10">
        <h3>Verifikasi KTP</h3>
        <?php
            if($status_ktp == 0){
                echo "<h5 class='text-warning'>"."Belum diverifikasi"."</h5>";
                echo "<button class='btn btn-primary' onclick='konfirmasi_verifikasi()'>Verifikasi</button>";
                echo "<button class='btn btn-danger' onclick='tolak_verifikasi()'>Tolak</button>";
            }
            else if($status_ktp == 1){
                echo "<h5 class='text-success'>"."Sudah diverifikasi!"."</h5>";
                echo "<button class='btn btn-danger' onclick='tolak_verifikasi()'>Tolak</button>";
            }
            else{
                echo "<h5 class='text-danger'>"."ditolak!"."</h5>";
                echo "<button class='btn btn-primary' onclick='konfirmasi_verifikasi()'>Verifikasi</button>";
            }
        ?>
        <hr>
        <img id='ktp_picture' src="<?=$url_ktp?>" alt="foto_ktp">
    </div>
    <div class="col-md-1"></div>
</div>
<script type='text/javascript'>
    function edit_user(){
        //alert($("#id").val());
        $.ajax({
            "url" : "<?=site_url('Welcome/edit_user')?>",
            "method" : "post",
            "data" : {
                "id" : $("#id").val(),
                "nama" : $("#nama").val(),
                "password" : $("#password").val(),
                "phone" : $("#phone").val(),
                "email" : $("#email").val()
            },
            success : function(callback){
                $("#content").html(callback);
            }
        });
        
    }
    function tolak_verifikasi(){
        $.ajax({
            "url" : "<?=site_url('Welcome/edit_verifikasi_ktp')?>",
            "method" : "post",
            "data" : {
                "id" : $("#id").val(),
                "value" : 2,
            },
            success : function(callback){
                $("#content").html(callback);
            }
        });
    }
    function konfirmasi_verifikasi(){
        $.ajax({
            "url" : "<?=site_url('Welcome/edit_verifikasi_ktp')?>",
            "method" : "post",
            "data" : {
                "id" : $("#id").val(),
                "value" : 1,
            },
            success : function(callback){
                $("#content").html(callback);
            }
        });
    }
    
</script>