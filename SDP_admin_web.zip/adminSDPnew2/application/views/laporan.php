
<?php
    //var_dump($data_laporan);

    $kategori['nama_kategori'] = array();
    $kategori['count_kategori'] = array();

    $penjual['nama'] = array();
    $penjual['jumlah_penjualan'] = array();

    $top_seller[0] = 0;
    $top_seller[1] = 0;
    $top_seller[2] = 0;
    $top_seller[3] = 0;
    $top_seller[4] = 0;

    $top_name[0] = "-";
    $top_name[1] = "-";
    $top_name[2] = "-";
    $top_name[3] = "-";
    $top_name[4] = "-";
    

    $hasil_penjualan[1] = 0;
    $hasil_penjualan[2] = 0;
    $hasil_penjualan[3] = 0;
    $hasil_penjualan[4] = 0;
    $hasil_penjualan[5] = 0;
    $hasil_penjualan[6] = 0;
    $hasil_penjualan[7] = 0;
    $hasil_penjualan[8] = 0;
    $hasil_penjualan[9] = 0;
    $hasil_penjualan[10] = 0;
    $hasil_penjualan[11] = 0;
    $hasil_penjualan[12] = 0;

    $bulan[1] = "Januari";
    $bulan[2] = "Februari";
    $bulan[3] = "Maret";
    $bulan[4] = "April";
    $bulan[5] = "Mei";
    $bulan[6] = "Juni";
    $bulan[7] = "Juli";
    $bulan[8] = "Agustus";
    $bulan[9] = "September";
    $bulan[10] = "Oktober";
    $bulan[11] = "November";
    $bulan[12] = "Desember";

    foreach($data_laporan as $row){
        if($row['status_trans'] == "selesai"){
            $kat =  $data_barang[$row['id_barang_trans']]['kategori'];
            //echo $kat;
            $newkat = explode(",",$kat);
            //var_dump($newkat);
            //echo "<hr>";
            foreach($newkat as $row_kategori){
                if(count($kategori['nama_kategori'])==0){
                    array_push($kategori['count_kategori'],1);
                    array_push($kategori['nama_kategori'],$row_kategori);
                }
                else{
                    $cek = true;
                    $index = -1;
                    for ($i=0; $i < count($kategori['nama_kategori']); $i++) { 
                        if($kategori['nama_kategori'][$i]==$row_kategori){
                            $cek = false;
                            $index = $i;
                        }
                    }
                    if($cek){
                        array_push($kategori['count_kategori'],1);
                        array_push($kategori['nama_kategori'],$row_kategori);
                    }
                    else{
                        $kategori['count_kategori'][$index]++;
                    }
                }
                
            }

            //cari penjual
            $ada = false;
            for ($i=0; $i < count($penjual['nama']); $i++) { 
                if($data_barang[$row['id_barang_trans']]['idpenjual'] == $penjual['nama'][$i]){
                    $ada = true;
                    $penjual['jumlah_penjualan'][$i]++;
                }
            }
            if(!$ada){
                array_push($penjual['nama'],$data_barang[$row['id_barang_trans']]['idpenjual']);
                array_push($penjual['jumlah_penjualan'],1);
            }
            //cari waktu trans
            $arr_waktu = explode("-",$row['waktu_trans']);
            $arr_tgl = explode("/",$arr_waktu[0]);
            
            //echo $arr_tgl[1];
            $hasil_penjualan[(int)$arr_tgl[1]]++;
            //var_dump($hasil_penjualan);


        }
    }

    
    //echo "<hr>";
    $data_array = array();
    for ($i=0; $i < count($kategori['nama_kategori']); $i++) { 
        $temp = [
            "y" => $kategori['count_kategori'][$i],
            "label" => $kategori['nama_kategori'][$i]
        ];
        array_push($data_array,$temp);
    }
    $json_data = json_encode($data_array);
    //var_dump($json_data);



    //cari 5 top seller
    for ($i=0; $i < count($penjual['nama']); $i++) { 
        //echo $penjual['nama'][$i]." - ".$penjual['jumlah_penjualan'][$i]."<br>";
        if($top_seller[4]<$penjual['jumlah_penjualan'][$i]){
            $top_seller[4] = $penjual['jumlah_penjualan'][$i];
            $top_name[4] = $penjual['nama'][$i];
            for ($j=4; $j > 0; $j--) {
                if($top_seller[$j]>$top_seller[$j-1]){
                    //tukar jumlah
                    $temp = $top_seller[$j];
                    $top_seller[$j] = $top_seller[$j-1];
                    $top_seller[$j-1] = $temp;
                    //tukar nama    
                    $tempstr = $top_name[$j];
                    $top_name[$j] = $top_name[$j-1];
                    $top_name[$j-1] = $tempstr;
                }
            }
        }
    }

    $data_penjualan_bulanan = array();
    $total_penjualan = 0;
    for ($i=1; $i <= 12 ; $i++) { 
        $total_penjualan+=$hasil_penjualan[$i];
    }
    for ($i=1; $i <= 12; $i++) { 
        $temp = [
            "y" => ($hasil_penjualan[$i]/$total_penjualan)*100,
            "label" => $bulan[$i]
        ];
        array_push($data_penjualan_bulanan,$temp);
    }
    $data_penjualan_json = json_encode($data_penjualan_bulanan);




?>
<div class="row">
    <div class="col-md-1"></div>
    <div class="col-md-10">
        <h2 class='text-center'>Leaderboard Penjual Terbanyak</h2>
        <table class='table table-stripped'>
            <tr class='bg-warning'>
                <th>No.</th>
                <th>Email</th>
                <th>Total Penjualan</th>
            </tr>
            <tr>
                <td>1.</td>
                <td><?=$top_name[0]?></td>
                <td><?=$top_seller[0]?></td>
            </tr>
            <tr>
                <td>2.</td>
                <td><?=$top_name[1]?></td>
                <td><?=$top_seller[1]?></td>
            </tr>
            <tr>
                <td>3.</td>
                <td><?=$top_name[2]?></td>
                <td><?=$top_seller[2]?></td>
            </tr>
            <tr>
                <td>4.</td>
                <td><?=$top_name[3]?></td>
                <td><?=$top_seller[3]?></td>
            </tr>
            <tr>
                <td>5.</td>
                <td><?=$top_name[4]?></td>
                <td><?=$top_seller[4]?></td>
            </tr>
        </table>
    </div>
    <div class="col-md-1"></div>
</div>
<hr>
<div class="row" style='height:500px;'>
    <div class="col-md-1"></div>
    <div class="col-md-10">
        <div id="chartContainer"></div>  
    </div>
    <div class="col-md-1"></div>
</div>
<hr>
<div class="row"style='height:500px;'>
    <div class="col-md-1"></div>
    <div class="col-md-10">
        <div id="chartContainer2"></div>  
    </div>
    <div class="col-md-1"></div>
</div>

<script type='text/javascript'>
    $(document).ready(function(){
        var chart = new CanvasJS.Chart("chartContainer", {
            animationEnabled: true,
            
            title:{
                text:"Total Penjualan per Kategori"
            },
            axisX:{
                interval: 1
            },
            axisY2:{
                interlacedColor: "rgba(1,77,101,.2)",
                gridColor: "rgba(1,77,101,.1)",
                title: "Total Penjualan"
            },
            data: [{
                type: "bar",
                name: "companies",
                axisYType: "secondary",
                color: "#014D65",
                dataPoints: <?=$json_data?>
            }]
        });
        chart.width=1000;//horizontal resolution (?) - increase for better looking text
        chart.height=500;//vertical resolution (?) - increase for better looking text
        //chart.style.width=1000;//actual width of canvas
        //chart.style.height=500;//actual height of canvas
        
        var chart2 = new CanvasJS.Chart("chartContainer2", {
            animationEnabled: true,
            title: {
                text: "Perbandingan Penjualan Tiap Bulan"
            },
            data: [{
                type: "pie",
                startAngle: 240,
                yValueFormatString: "##0.00\"%\"",
                indexLabel: "{label} {y}",
                dataPoints: <?=$data_penjualan_json?>
            }]
        });
        chart2.width=1000;//horizontal resolution (?) - increase for better looking text
        chart2.height=500;//vertical resolution (?) - increase for better looking text
        
        chart.render();
        chart2.render();



    });
</script>