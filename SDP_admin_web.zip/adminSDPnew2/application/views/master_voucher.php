<div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-3">
            <h1>Input Voucher</h1>
            Nama Promo : <br>
            <input class='form-control' type="text" id='nama_voucher' id='nama_voucher' placeholder="nama voucher" required><br>
            Diskon : <br>
            <input  class='form-control' type="number" id='diskon_voucher' id='diskon_voucher' placeholder="diskon voucher" required><br>
            Deskripsi : <br>
            <textarea style='width:100%' class="form-control" name="deskripsi_voucher" id="deskripsi_voucher" cols="30" rows="10"></textarea><br>
            Mulai Voucher : <br>
            <input  class='form-control' type="date" name='mulai_voucher' id='mulai_voucher' placeholder="tanggal mulai voucher" required> <br>
            Akhir Voucher : <br>
            <input  class='form-control' type="date" name='akhir_voucher' id='akhir_voucher' placeholder="tanggal akhir voucher" required> <br>
            <input class = 'btn btn-primary' type="submit" name='submit' id='submit' value='submit voucher' onclick='insert_promo()'>
            <hr>
            <?php
                if(($this->session->flashdata('error'))!==null){
                    echo "<p class='text-danger'>".$this->session->flashdata('error')."</p>";
                }
            ?>
        </div>
        <div class="col-md-7">
            <h1>List Voucher</h1>
            <hr>
            <table id="datatablediv">
                <thead>
                    <tr>
                        <th>Nama Promo</th>
                        <th>Diskon Promo</th>
                        <th>Deskripsi</th>
                        <th>Mulai Promo</th>
                        <th>Akhir Promo</th>
                        <th></th>
                    </tr>
                </thead>
            </table>

        </div>
        <div class="col-md-1"></div>
    </div>


    <?php
        $data_array = array();
        $key_array = array();
        $key_array = array_keys($data_voucher);
        // var_dump($key_array);

        foreach($data_voucher as $row){
            array_push($data_array,$row);
        }
        $encode_array = json_encode($data_array);
        
    ?>

    <script type='text/javascript'>
        function toggle_activate_promo(key,value){
            $.ajax({
                "url" : "<?=site_url('Welcome/update_promo')?>",
                "method" : "post",
                "data" : {
                    "id" : key,
                    "value" : value
                },
                success : function(callback){
                    $("#content").html(callback);
                }
            });

        }
        function insert_promo(){
            $.ajax({
                "url" : "<?=site_url('Welcome/insert_promo')?>",
                "method" : "post",
                "data" : {
                    "nama_promo": $('#nama_voucher').val(),
                    "diskon_promo": $('#diskon_voucher').val(),
                    "deskripsi_promo": $('#deskripsi_voucher').val(),
                    "mulai_promo": $('#mulai_voucher').val(),
                    "selesai_promo":  $('#akhir_voucher').val(),
                    "status_promo": 1
                },
                success : function(callback){
                    $("#content").html(callback);
                }
            });
        }

        var arr_key = <?=json_encode($key_array) ?>;

        
        tableData = $("#datatablediv").dataTable({
                data : <?=$encode_array?>,
                createdRow : function( row, data, dataIndex){
                    if( data.status_promo ==  0){
                        $(row).addClass('bg-danger');
                    }
                },
                aoColumns : [
                    {mData : "nama_promo"},
                    {mData : "diskon_promo"},
                    {mData : "deskripsi_promo"},
                    {mData : "mulai_promo"},
                    {mData : "selesai_promo"},
                    {
                        mData : function(data,type,full,meta){
                            var hasil = "";
                            if(data.status_promo == 0){
                                hasil = "<button class='btn btn-primary' style='width:100%;'onclick="+''+"toggle_activate_promo('"+arr_key[meta.row]+"',1)"+''+'>'+"Aktifkan"+"</button>";
                            }
                            else{
                                hasil = "<button class='btn btn-danger' style='width:100%;'onclick="+''+"toggle_activate_promo('"+arr_key[meta.row]+"',0)"+''+'>'+"Non Aktifkan"+"</button>";
                            }
                            return hasil;
                        }
                    },
                ]
            });
    </script>